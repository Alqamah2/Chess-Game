// run: npm init -y
// npm i express socket.io
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http, { cors: { origin: "*" }});
const PORT = process.env.PORT || 3000;

app.use(express.static('public')); // put index.html, style.css, script.js in public/

let rooms = {}; // { code: { sockets:[], timer } }

function genCode(){
  return Math.floor(100000 + Math.random()*900000).toString();
}

io.on('connection', socket=>{
  socket.on('createRoom', ()=>{
    const code = genCode();
    rooms[code] = { sockets: [socket.id], timer: setTimeout(()=>{ delete rooms[code]; }, 120000) };
    socket.join(code);
    socket.emit('roomCreated', code);
  });

  socket.on('joinRoom', code=>{
    if(rooms[code] && rooms[code].sockets.length < 2){
      rooms[code].sockets.push(socket.id);
      socket.join(code);
      io.to(code).emit('startGame', code);
    } else {
      socket.emit('roomError', 'Code did not exist');
    }
  });

  socket.on('move', data=>{
    // data: { room, from:[sr,sc], to:[tr,tc] }
    if(data && data.room) socket.to(data.room).emit('opponentMove', { from: data.from, to: data.to });
  });

  socket.on('disconnect', ()=>{
    for(const code in rooms){
      rooms[code].sockets = rooms[code].sockets.filter(s=>s!==socket.id);
      if(rooms[code].sockets.length === 0){
        clearTimeout(rooms[code].timer);
        delete rooms[code];
      }
    }
  });
});

http.listen(PORT, ()=> console.log('Server listening on', PORT));


