/* script.js - Pro Chess Multiplayer (client) */

/* ---------- Helpers & DOM ---------- */
const splash = document.getElementById('splash');
const app = document.getElementById('app');
const btnPlay = document.getElementById('btnPlay');
const btnMult = document.getElementById('btnMult');
const createRoom = document.getElementById('createRoom');
const joinRoom = document.getElementById('joinRoom');
const roomCodeInput = document.getElementById('roomCode');
const mpStatus = document.getElementById('mpStatus');

const boardEl = document.getElementById('board');
const modeSelect = document.getElementById('modeSelect');
const aiDepthSel = document.getElementById('aiDepth');
const startBtn = document.getElementById('start');
const undoBtn = document.getElementById('undo');
const redoBtn = document.getElementById('redo');
const themeBtn = document.getElementById('theme');

const whiteTimeEl = document.getElementById('whiteTime');
const blackTimeEl = document.getElementById('blackTime');
const whiteCapturedEl = document.getElementById('whiteCaptured');
const blackCapturedEl = document.getElementById('blackCaptured');
const moveLogEl = document.getElementById('moveLog');
const statusEl = document.getElementById('status');

let socket = null;
try { socket = io(); } catch(e) { socket = null; }

/* ---------- Game State ---------- */
const piecesUnicode = { r:'♜', n:'♞', b:'♝', q:'♛', k:'♚', p:'♟',
                       R:'♖', N:'♘', B:'♗', Q:'♕', K:'♔', P:'♙' };

let board = [];
let turn = 'white'; // white starts
let selected = null;
let highlights = [];
let history = []; // store board snapshots for undo
let redoStack = [];
let whiteCaptured = [], blackCaptured = [];
let moveLog = [];
let mode = 'pvp'; // pvp | ai | multiplayer
let aiDepth = 0;
let timers = { white:600, black:600, interval: null };
let currentRoom = null;
let isOnlineOpponent = false;

/* ---------- Splash / Multiplayer UI ---------- */
btnPlay.onclick = () => {
  splash.classList.remove('active'); splash.style.display='none';
  app.classList.add('active');
  modeSelect.value = 'ai';
};
btnMult.onclick = () => {
  mpStatus.textContent = 'Use create/join to start an online room';
};

if(socket){
  socket.on('roomCreated', code => {
    mpStatus.textContent = `Room created: ${code} (expires in 120s)`;
    currentRoom = code;
    mode = 'multiplayer';
  });
  socket.on('roomError', msg => mpStatus.textContent = msg);
  socket.on('startGame', code => {
    mpStatus.textContent = `Player joined — starting game in room ${code}`;
    currentRoom = code; modeSelect.value = 'multiplayer'; mode='multiplayer';
    splash.classList.remove('active'); splash.style.display='none'; app.classList.add('active');
  });
  socket.on('opponentMove', move => {
    // move: { from:[sr,sc], to:[tr,tc] }
    applyRemoteMove(move);
  });
}

createRoom.onclick = ()=> {
  if(!socket){ mpStatus.textContent='Server not connected'; return; }
  socket.emit('createRoom');
};
joinRoom.onclick = ()=> {
  const code = (roomCodeInput.value || '').trim();
  if(!socket){ mpStatus.textContent='Server not connected'; return; }
  if(!code) { mpStatus.textContent='Enter room code'; return; }
  socket.emit('joinRoom', code);
};

/* ---------- Start / Controls ---------- */
startBtn.onclick = () => {
  mode = modeSelect.value;
  aiDepth = parseInt(aiDepthSel.value) || 0;
  initBoard();
  startTimers();
  statusEl.textContent = `Mode: ${mode.toUpperCase()}`;
  isOnlineOpponent = (mode === 'multiplayer');
};

undoBtn.onclick = undo;
redoBtn.onclick = redo;
themeBtn.onclick = ()=> document.body.classList.toggle('dark');

/* ---------- Board Initialization ---------- */
function initBoard(){
  board = [
    ['r','n','b','q','k','b','n','r'],
    ['p','p','p','p','p','p','p','p'],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['','','','','','','',''],
    ['P','P','P','P','P','P','P','P'],
    ['R','N','B','Q','K','B','N','R']
  ];
  turn='white'; selected=null; highlights=[]; history=[]; redoStack=[]; whiteCaptured=[]; blackCaptured=[]; moveLog=[]; updateUI();
}

/* ---------- Rendering ---------- */
function updateUI(){
  renderBoard();
  updateCaptured();
  renderLog();
  updateTimersDisplay();
  statusEl.textContent = `Turn: ${turn.toUpperCase()}`;
}

function renderBoard(){
  boardEl.innerHTML = '';
  for(let r=0;r<8;r++){
    for(let c=0;c<8;c++){
      const sq = document.createElement('div');
      sq.className = 'square ' + ((r+c)%2===0 ? 'light' : 'dark');
      sq.dataset.r = r; sq.dataset.c = c;
      const p = board[r][c];
      if(p) { const sp = document.createElement('span'); sp.className='piece'; sp.textContent = piecesUnicode[p]; sq.appendChild(sp); }
      sq.onclick = ()=> onSquareClick(r,c);
      sq.addEventListener('dragover', e=> e.preventDefault());
      sq.addEventListener('drop', ()=> onDrop(r,c));
      // highlight
      if(highlights.some(h => h[0]===r && h[1]===c)) sq.classList.add('highlight');
      boardEl.appendChild(sq);
    }
  }
}

/* ---------- Click/Drag ---------- */
function onSquareClick(r,c){
  const p = board[r][c];
  if(selected){
    const [sr,sc] = selected;
    const moves = legalMoves(sr,sc).map(m=> `${m[0]}-${m[1]}`);
    if(moves.includes(`${r}-${c}`)){
      pushHistory(); redoStack=[];
      move(sr,sc,r,c);
      if(mode==='multiplayer' && currentRoom && socket) socket.emit('move',{room:currentRoom, from:[sr,sc], to:[r,c]});
      selected=null; highlights=[]; updateUI();
      if(mode==='ai' && turn==='black') setTimeout(aiPlay,300);
      return;
    } else {
      // select new own piece
      if(p && sameColor(p, turn)){ selected=[r,c]; highlights = legalMoves(r,c); updateUI(); return; }
      selected=null; highlights=[]; updateUI(); return;
    }
  } else {
    if(p && sameColor(p, turn)){ selected=[r,c]; highlights = legalMoves(r,c); updateUI(); }
  }
}

function onDrop(r,c){
  if(!selected) return;
  const [sr,sc] = selected;
  const moves = legalMoves(sr,sc).map(m=> `${m[0]}-${m[1]}`);
  if(moves.includes(`${r}-${c}`)){
    pushHistory(); redoStack=[];
    move(sr,sc,r,c);
    if(mode==='multiplayer' && currentRoom && socket) socket.emit('move',{room:currentRoom, from:[sr,sc], to:[r,c]});
    selected=null; highlights=[]; updateUI();
    if(mode==='ai' && turn==='black') setTimeout(aiPlay,300);
  } else {
    selected=null; highlights=[]; updateUI();
  }
}

/* ---------- Movement & rules (basic, includes promotion to queen, no castling/en-passant yet) ---------- */
function pushHistory(){ history.push(JSON.parse(JSON.stringify(board))); if(history.length>200) history.shift(); }
function undo(){
  if(history.length===0) return;
  redoStack.push(JSON.parse(JSON.stringify(board)));
  board = history.pop();
  turn = (turn==='white') ? 'black' : 'white';
  updateUI();
}
function redo(){
  if(redoStack.length===0) return;
  history.push(JSON.parse(JSON.stringify(board)));
  board = redoStack.pop();
  turn = (turn==='white') ? 'black' : 'white';
  updateUI();
}

function move(sr,sc,tr,tc){
  const piece = board[sr][sc];
  const target = board[tr][tc];
  if(target){
    if(turn==='white') whiteCaptured.push(target);
    else blackCaptured.push(target);
  }
  board[tr][tc] = piece;
  board[sr][sc] = '';

  // promotion auto to queen
  if(piece === 'P' && tr === 0) board[tr][tc] = 'Q';
  if(piece === 'p' && tr === 7) board[tr][tc] = 'q';

  moveLog.push(`${piece}@${sr}${sc}->${tr}${tc}`);
  turn = (turn==='white')? 'black' : 'white';

  // check/checkmate detection simple
  if(isInCheck(turn)) {
    if(noLegalMoves(turn)) {
      alert(`${turn.toUpperCase()} is checkmated. Game over.`);
    } else {
      // still in check
    }
  }
}

/* ---------- Legal moves (basic) ---------- */
function legalMoves(r,c){
  const piece = board[r][c];
  if(!piece) return [];
  if(!sameColor(piece, turn)) return [];
  const t = piece.toLowerCase();
  const moves = [];
  if(t === 'p'){
    const dir = (piece === 'P') ? -1 : 1;
    if(inB(r+dir,c) && !board[r+dir][c]) moves.push([r+dir,c]);
    if(inB(r+dir,c-1) && board[r+dir][c-1] && isEnemy(piece, board[r+dir][c-1])) moves.push([r+dir,c-1]);
    if(inB(r+dir,c+1) && board[r+dir][c+1] && isEnemy(piece, board[r+dir][c+1])) moves.push([r+dir,c+1]);
  }
  if(t === 'r') addLines(r,c, [[1,0],[-1,0],[0,1],[0,-1]], moves, piece);
  if(t === 'b') addLines(r,c, [[1,1],[1,-1],[-1,1],[-1,-1]], moves, piece);
  if(t === 'q') addLines(r,c, [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]], moves, piece);
  if(t === 'n') addSingles(r,c, [[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]], moves, piece);
  if(t === 'k') addSingles(r,c, [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]], moves, piece);
  return moves;
}
function addLines(r,c,dirs,arr,piece){
  dirs.forEach(d=>{
    let nr=r+d[0], nc=c+d[1];
    while(inB(nr,nc)){
      if(!board[nr][nc]) arr.push([nr,nc]);
      else { if(isEnemy(piece, board[nr][nc])) arr.push([nr,nc]); break; }
      nr+=d[0]; nc+=d[1];
    }
  });
}
function addSingles(r,c,dirs,arr,piece){
  dirs.forEach(d=>{
    const nr=r+d[0], nc=c+d[1];
    if(inB(nr,nc) && (!board[nr][nc] || isEnemy(piece, board[nr][nc]))) arr.push([nr,nc]);
  });
}
function inB(r,c){ return r>=0 && r<8 && c>=0 && c<8; }
function isEnemy(a,b){ if(!b) return false; return (a===a.toUpperCase()) ? (b===b.toLowerCase()) : (b===b.toUpperCase()); }
function sameColor(piece, color){ return (color==='white') ? (piece===piece.toUpperCase()) : (piece===piece.toLowerCase()); }

/* ---------- Check / Checkmate (basic) ---------- */
function findKing(color){
  const target = (color==='white') ? 'K' : 'k';
  for(let r=0;r<8;r++) for(let c=0;c<8;c++) if(board[r][c]===target) return [r,c];
  return null;
}
function isInCheck(color){
  const kingPos = findKing(color);
  if(!kingPos) return false;
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){
    const p = board[r][c];
    if(p && isEnemy(p, (color==='white' ? 'K' : 'k'))) {
      const lm = legalMoves(r,c);
      if(lm.some(m => m[0]===kingPos[0] && m[1]===kingPos[1])) return true;
    }
  }
  return false;
}
function noLegalMoves(color){
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){
    const p = board[r][c];
    if(p && sameColor(p, color)){
      if(legalMoves(r,c).length>0) return false;
    }
  }
  return true;
}

/* ---------- Captured / Move log UI ---------- */
function updateCaptured(){
  whiteCapturedEl.textContent = whiteCaptured.map(x => piecesUnicode[x]||x).join(' ');
  blackCapturedEl.textContent = blackCaptured.map(x => piecesUnicode[x]||x).join(' ');
}
function renderLog(){
  moveLogEl.innerHTML = '';
  moveLog.forEach((m,i)=>{
    const li = document.createElement('li'); li.textContent = `${i+1}. ${m}`; moveLogEl.appendChild(li);
  });
}

/* ---------- Timers ---------- */
function startTimers(){
  clearInterval(timers.interval);
  timers.white = 600; timers.black = 600;
  timers.interval = setInterval(()=>{
    if(turn==='white'){ timers.white--; if(timers.white<=0){ clearInterval(timers.interval); alert('Black wins on time'); } }
    else { timers.black--; if(timers.black<=0){ clearInterval(timers.interval); alert('White wins on time'); } }
    updateTimersDisplay();
  },1000);
}
function updateTimersDisplay(){
  whiteTimeEl.textContent = fmt(timers.white); blackTimeEl.textContent = fmt(timers.black);
}
function fmt(s){ if(s<0) s=0; const m=Math.floor(s/60), sec=s%60; return `${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`; }

/* ---------- Multiplayer apply / send ---------- */
function applyRemoteMove(msg){
  // msg: { from:[sr,sc], to:[tr,tc] }
  if(!msg || !msg.from) return;
  pushRemoteState();
  move(msg.from[0], msg.from[1], msg.to[0], msg.to[1]);
  updateUI();
}
function pushRemoteState(){ history.push(JSON.parse(JSON.stringify(board))); }

/* ---------- Simple AI (minimax optional) ---------- */
function aiPlay(){
  if(aiDepth <= 0){ // random
    const moves = [];
    for(let r=0;r<8;r++) for(let c=0;c<8;c++){
      const p = board[r][c];
      if(p && p===p.toLowerCase()){
        legalMoves(r,c).forEach(m => moves.push({from:[r,c], to:m}));
      }
    }
    if(moves.length===0) return;
    const choice = moves[Math.floor(Math.random()*moves.length)];
    pushHistory(); redoStack=[]; move(choice.from[0], choice.from[1], choice.to[0], choice.to[1]); updateUI();
    return;
  } else {
    // simple minimax with depth aiDepth
    const best = minimaxRoot(aiDepth, false);
    if(best && best.move) { pushHistory(); redoStack=[]; move(best.move.from[0], best.move.from[1], best.move.to[0], best.move.to[1]); updateUI(); }
  }
}

/* ---------- Minimax (very simple material eval) ---------- */
function minimaxRoot(depth, isMaximisingPlayer){
  const moves = generateAllMoves('black');
  let bestScore = -Infinity; let bestMove = null;
  for(const m of moves){
    const snapshot = JSON.stringify(board);
    move(m.from[0], m.from[1], m.to[0], m.to[1]);
    const score = minimax(depth-1, !isMaximisingPlayer, -Infinity, Infinity);
    board = JSON.parse(snapshot);
    if(score > bestScore){ bestScore = score; bestMove = m; }
  }
  return { score: bestScore, move: bestMove };
}
function minimax(depth, isMaximising, alpha, beta){
  if(depth===0) return evaluateBoard();
  if(isMaximising){
    let maxEval = -Infinity;
    const moves = generateAllMoves('black');
    for(const m of moves){
      const snap = JSON.stringify(board);
      move(m.from[0], m.from[1], m.to[0], m.to[1]);
      const evalv = minimax(depth-1, false, alpha, beta);
      board = JSON.parse(snap);
      maxEval = Math.max(maxEval, evalv);
      alpha = Math.max(alpha, evalv);
      if(beta <= alpha) break;
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    const moves = generateAllMoves('white');
    for(const m of moves){
      const snap = JSON.stringify(board);
      move(m.from[0], m.from[1], m.to[0], m.to[1]);
      const evalv = minimax(depth-1, true, alpha, beta);
      board = JSON.parse(snap);
      minEval = Math.min(minEval, evalv);
      beta = Math.min(beta, evalv);
      if(beta <= alpha) break;
    }
    return minEval;
  }
}
function generateAllMoves(color){
  const out = [];
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){
    const p = board[r][c];
    if(p && ((color==='white' && p===p.toUpperCase()) || (color==='black' && p===p.toLowerCase()))){
      legalMoves(r,c).forEach(m => out.push({from:[r,c], to:m}));
    }
  }
  return out;
}
function evaluateBoard(){
  const vals = { p:1, n:3, b:3, r:5, q:9, k:1000 };
  let score = 0;
  for(let r=0;r<8;r++) for(let c=0;c<8;c++){
    const p = board[r][c];
    if(!p) continue;
    const v = vals[p.toLowerCase()] || 0;
    score += (p===p.toUpperCase()) ? v : -v;
  }
  return score;
}

/* ---------- Misc/Init ---------- */
function pushHistory(){ history.push(JSON.parse(JSON.stringify(board))); if(history.length>200) history.shift(); }
function updateUIAll(){ updateUI(); }

initBoard(); updateUI();

/* END of script.js */
